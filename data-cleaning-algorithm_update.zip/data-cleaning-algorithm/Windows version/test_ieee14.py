"""
test_ieee14bus.py

Read IEEE14BUS_9_14.csv, inject sensor faults after sample 30,
recover using TimeSeriesRecovery, and plot comparison.

Usage:
    python test_ieee14bus.py
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time
from time_series_recovery import (
    TimeSeriesRecovery, ChannelGroup, AnomalyConfig, SAPConfig
)


# ====================================================================
#  1. Read CSV
# ====================================================================

def load_data(csv_path):
    """
    Read CSV file.
    Column 0: time
    Columns 1-6: voltage data (6 channels)

    Returns: t (n_frames,), V_clean (6, n_frames)
    """
    df = pd.read_csv(csv_path)
    t = df.iloc[:, 0].values
    V_clean = df.iloc[:, 1:7].values.T  # (6, n_frames)
    col_names = list(df.columns[1:7])
    print(f"Loaded: {csv_path}")
    print(f"  Samples: {V_clean.shape[1]}, Channels: {V_clean.shape[0]}")
    print(f"  Columns: {col_names}")
    print(f"  Time range: {t[0]:.4f} ~ {t[-1]:.4f}")
    return t, V_clean, col_names


# ====================================================================
#  2. Inject faults after sample 30
# ====================================================================

def inject_faults(V_clean, start=30, seed=42):
    """
    Inject 4 types of faults on different channels after 'start' sample.

    Channel 0: block missing (NaN) for 20 samples
    Channel 1: random missing (NaN) with 40% probability
    Channel 2: sensor freeze (stuck at one value)
    Channel 3: spike (sudden jump to 5x value at a few points)

    Channels 4, 5: no fault (reference channels for recovery)

    Returns: V_corrupt (6, n_frames), fault_info dict
    """
    rng = np.random.RandomState(seed)
    V = V_clean.copy()
    n_frames = V.shape[1]

    # Fault 1: Block missing on channel 0
    block_start = start + 10
    block_end = min(block_start + 20, n_frames)
    V[0, block_start:block_end] = np.nan

    # Fault 2: Random missing on channel 1
    rand_start = start + 5
    rand_end = min(rand_start + 40, n_frames)
    mask = rng.rand(rand_end - rand_start) < 0.4
    V[1, rand_start:rand_end][mask] = np.nan

    # Fault 3: Sensor freeze on channel 2
    freeze_start = start + 15
    V[2, freeze_start:] = V[2, freeze_start]

    # Fault 4: Spikes on channel 3
    spike_indices = rng.choice(range(start + 5, min(start + 50, n_frames)), size=5, replace=False)
    for idx in spike_indices:
        V[3, idx] = V_clean[3, idx] * 5.0

    fault_info = {
        "ch0": f"Block NaN [{block_start}:{block_end}]",
        "ch1": f"Random NaN 40% [{rand_start}:{rand_end}]",
        "ch2": f"Freeze from [{freeze_start}]",
        "ch3": f"Spikes at {sorted(spike_indices)}",
        "ch4": "No fault",
        "ch5": "No fault",
    }

    print("\nInjected faults:")
    for ch, desc in fault_info.items():
        print(f"  {ch}: {desc}")

    return V, fault_info


# ====================================================================
#  3. Run recovery
# ====================================================================

def run_recovery(V_corrupt, n_ch=6):
    """
    Run TimeSeriesRecovery on corrupted data.
    All 6 channels in one group, rank=2 (voltage signals).
    """
    # Estimate threshold from first 30 clean samples
    clean_part = V_corrupt[:, :30]
    diff = np.abs(np.diff(clean_part, axis=1))
    auto_thresh = np.nanpercentile(diff, 99, axis=1) * 3.0
    auto_thresh[auto_thresh < 0.01] = 0.5  # minimum threshold
    print(f"\nAuto thresholds: {np.round(auto_thresh, 4)}")

    # =============================================================
    #  >>>  RECOVERY ALGORITHM STARTS HERE  <<<
    #
    #  This is the core usage of the TimeSeriesRecovery library.
    #  Everything above is data preparation.
    #  Everything below is result extraction.
    # =============================================================

    # Step 1: Create recovery instance with parameters
    t0 = time.time()
    rec = TimeSeriesRecovery(
        n_channels=n_ch,
        groups=[ChannelGroup(list(range(n_ch)), rank=2)],
        anomaly_config=AnomalyConfig(
            thresholds=auto_thresh,
            freeze_consec=2,
            lockout_samples=12,
            n_event_threshold=n_ch,
        ),
        sap_config=SAPConfig(
            window_length=16,
            hankel_rows=2,
            threshold=0.01,
            fast=True,
        ),
    )
    t1 = time.time()
    print(f"\n  Step 1 - Create instance:    {(t1-t0)*1000:.2f} ms")

    # Step 2: Reset internal state before processing
    t2 = time.time()
    rec.reset()
    t3 = time.time()
    print(f"  Step 2 - Reset:              {(t3-t2)*1000:.2f} ms")

    # Step 3: Feed data frame by frame, record per-frame time
    n_frames = V_corrupt.shape[1]
    frame_times = np.zeros(n_frames)
    t4 = time.time()
    for k in range(n_frames):
        t_start = time.perf_counter()
        rec.step(V_corrupt[:, k])
        t_end = time.perf_counter()
        frame_times[k] = (t_end - t_start) * 1e3  # milliseconds
    t5 = time.time()
    print(f"  Step 3 - Process {n_frames} frames: {(t5-t4)*1000:.2f} ms")

    # Step 4: Retrieve recovered data
    t6 = time.time()
    hist = rec.get_history()
    t7 = time.time()
    print(f"  Step 4 - Get history:        {(t7-t6)*1000:.2f} ms")

    # hist["Z_recovered"] -> (n_channels, n_frames) recovered output
    # hist["Omega"]        -> (n_channels, n_frames) quality mask
    # hist["Z_raw"]        -> (n_channels, n_frames) raw input

    # =============================================================
    #  >>>  RECOVERY ALGORITHM ENDS HERE  <<<
    # =============================================================

    total = (t7 - t0) * 1000
    print(f"\n  Total recovery time:         {total:.2f} ms")
    print(f"\n  Per-frame timing statistics (ms):")
    print(f"    Mean:   {np.mean(frame_times):.3f}")
    print(f"    Median: {np.median(frame_times):.3f}")
    print(f"    Min:    {np.min(frame_times):.3f}")
    print(f"    Max:    {np.max(frame_times):.3f}")
    print(f"    Std:    {np.std(frame_times):.3f}")
    print(f"  Recovery complete. Frames: {n_frames}")
    return hist, frame_times


# ====================================================================
#  4. Plot
# ====================================================================

def plot_results(t, V_clean, V_corrupt, hist, col_names, fault_info, frame_times):
    """
    Plot original, corrupted, and recovered for each faulted channel.
    4 channels with faults → 2x2 plot + 1 timing plot.
    """
    Z_rec = hist["Z_recovered"]

    fig, axes = plt.subplots(3, 2, figsize=(14, 11),
                             gridspec_kw={'height_ratios': [1, 1, 0.7]})
    fig.suptitle("IEEE 14-Bus Voltage Recovery — Fault Injection Test",
                 fontsize=13, fontweight='bold')

    fault_channels = [0, 1, 2, 3]
    fault_labels = [
        "Block Missing (NaN)",
        "Random Missing 40%",
        "Sensor Freeze",
        "Spike Faults",
    ]

    for idx, ch in enumerate(fault_channels):
        ax = axes[idx // 2, idx % 2]

        # Original (true) signal
        ax.plot(t, V_clean[ch], color='#3182BD', lw=1.0, alpha=0.6,
                label='True signal')

        # Corrupted signal
        corrupt_line = V_corrupt[ch].copy()
        ax.plot(t, corrupt_line, color='#E6550D', lw=1.0, alpha=0.5,
                label='Corrupted')

        # Mark NaN positions
        nan_mask = np.isnan(V_corrupt[ch])
        if nan_mask.any():
            ax.scatter(t[nan_mask],
                       np.full(nan_mask.sum(), np.nanmean(V_clean[ch])),
                       c='#E6550D', marker='x', s=18, lw=0.7, alpha=0.7,
                       label='Missing', zorder=4)

        # Recovered signal
        ax.plot(t, Z_rec[ch], color='black', lw=1.0, ls='--',
                dashes=(4, 2), alpha=0.9, label='Recovered')

        # RMSE on fault region
        if ch == 0:
            region = slice(40, 60)
        elif ch == 1:
            region = slice(35, 70)
        elif ch == 2:
            region = slice(45, None)
        else:
            region = slice(35, 80)

        rmse = np.sqrt(np.nanmean((Z_rec[ch, region] - V_clean[ch, region]) ** 2))

        name = col_names[ch] if ch < len(col_names) else f"Ch{ch}"
        ax.set_title(f"{name} — {fault_labels[idx]}  (RMSE={rmse:.5f})",
                     fontsize=9, fontweight='bold')
        ax.set_ylabel("Voltage (p.u.)")
        ax.grid(True, alpha=0.3, ls='--')

        if idx < 2:
            ax.tick_params(labelbottom=False)
        else:
            ax.set_xlabel("Time")

        if idx == 0:
            ax.legend(fontsize=7, ncol=4, loc='upper right')

    # ---- Bottom row: per-frame timing ----
    ax_time = fig.add_subplot(3, 1, 3)
    frames_idx = np.arange(len(frame_times))
    ax_time.bar(frames_idx, frame_times, color='#3182BD', alpha=0.7, width=1.0)
    ax_time.axhline(np.mean(frame_times), color='#DE2D26', ls='--', lw=1.2,
                    label=f'Mean: {np.mean(frame_times):.3f} ms')
    ax_time.set_xlabel("Frame Index")
    ax_time.set_ylabel("Processing Time (ms)")
    ax_time.set_title(f"Per-Frame Processing Time  "
                      f"(Mean={np.mean(frame_times):.3f} ms, "
                      f"Max={np.max(frame_times):.3f} ms)",
                      fontsize=9, fontweight='bold')
    ax_time.legend(fontsize=8)
    ax_time.grid(True, alpha=0.3, ls='--')

    # Remove unused subplot (row2, col1 is replaced by full-width timing)
    axes[2, 0].set_visible(False)
    axes[2, 1].set_visible(False)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig("ieee14bus_recovery.png", dpi=200)
    print("\nSaved: ieee14bus_recovery.png")
    plt.show()


# ====================================================================
#  5. Main
# ====================================================================

def main():
    csv_path = "IEEE14BUS_9_14.csv"

    # Load
    t, V_clean, col_names = load_data(csv_path)

    # Inject faults
    V_corrupt, fault_info = inject_faults(V_clean, start=30)

    # Recover
    hist, frame_times = run_recovery(V_corrupt)

    # Plot
    plot_results(t, V_clean, V_corrupt, hist, col_names, fault_info, frame_times)

    # Summary
    Z_rec = hist["Z_recovered"]
    print(f"\n{'='*50}")
    print("  RMSE Summary")
    print(f"{'='*50}")
    for ch in range(4):
        name = col_names[ch] if ch < len(col_names) else f"Ch{ch}"
        rmse = np.sqrt(np.nanmean((Z_rec[ch] - V_clean[ch]) ** 2))
        print(f"  {name}: {rmse:.6f}")
    print(f"{'='*50}")


if __name__ == "__main__":
    main()