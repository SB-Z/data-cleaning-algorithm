"""
time_series_recovery.py

Online multi-channel time series recovery module.
Anomaly detection (Python) + SAP recovery (C++ sap_core backend).

Requires compiled C++ module:
    python setup.py build_ext --inplace

Usage:
    from time_series_recovery import (
        TimeSeriesRecovery, ChannelGroup, AnomalyConfig, SAPConfig
    )

    rec = TimeSeriesRecovery(n_channels=4)
    rec.reset()
    for frame in stream:
        result = rec.step(frame)
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Union, Dict, Any

import sap_core  # compiled C++ backend (required)


# ====================================================================
#  Configuration dataclasses
# ====================================================================

@dataclass
class ChannelGroup:
    """
    Defines a group of channels to be jointly recovered.

    Attributes:
        channels  List of channel indices (0-based).
        rank      Target rank for this group. Default 2.
        label     Optional name for logging.
    """
    channels: List[int]
    rank: int = 2
    label: str = ""


@dataclass
class AnomalyConfig:
    """
    Parameters for the per-channel anomaly detector.

    Attributes:
        thresholds        Max allowed frame-to-frame change.
                          float -> same for all channels.
                          np.ndarray (n_channels,) -> per-channel.
        freeze_consec     Consecutive identical frames to flag as frozen.
        lockout_samples   Frames to keep a channel masked after flagging.
        n_event_threshold If >= this many channels spike simultaneously,
                          treat as system event (keep omega=1).
                          Set to n_channels+1 to disable.
    """
    thresholds: Union[float, np.ndarray] = 0.5
    freeze_consec: int = 2
    lockout_samples: int = 16
    n_event_threshold: int = 3


@dataclass
class SAPConfig:
    """
    Parameters for the SAP recovery algorithm.

    Attributes:
        window_length  Sliding buffer size in frames.
        hankel_rows    Hankel matrix row parameter (usually 2).
        threshold      Sparsity threshold for SAP inner loop.
        fast           True: 5 iterations/rank, False: 10 (more accurate).
    """
    window_length: int = 16
    hankel_rows: int = 2
    threshold: float = 0.01
    fast: bool = True


# ====================================================================
#  Anomaly detector (pure Python)
# ====================================================================

class OnlineAnomalyDetector:
    """
    Per-channel anomaly detector. Produces a quality mask (omega).

    Detection checks per channel per frame:
        1. NaN               -> omega=0  (communication loss)
        2. In lockout        -> omega=0  (previous detection still active)
        3. Rate-of-change    -> candidate (frame-to-frame spike)
        4. Freeze            -> candidate (bit-exact equal consecutive frames)
        5. Prediction check  -> candidate (deviation from last recovered value)

    Collective decision:
        If #rate-of-change candidates >= n_event_threshold:
            system event -> keep omega=1 for those channels.
        Else:
            sensor fault -> set omega=0 for all candidates.
        Freeze candidates are always flagged regardless.
    """

    def __init__(self, n_channels: int, config: AnomalyConfig = None):
        self.n_ch = n_channels
        cfg = config or AnomalyConfig()

        if np.isscalar(cfg.thresholds):
            self.thresholds = np.full(n_channels, float(cfg.thresholds))
        else:
            t = np.asarray(cfg.thresholds, dtype=np.float64)
            if t.shape[0] != n_channels:
                raise ValueError(
                    f"thresholds length {t.shape[0]} != n_channels {n_channels}")
            self.thresholds = t

        self.freeze_consec = cfg.freeze_consec
        self.lockout = cfg.lockout_samples
        self.n_event = cfg.n_event_threshold
        self._init()

    def _init(self):
        self.z_prev = np.full(self.n_ch, np.nan)
        self.z_rec_prev = np.full(self.n_ch, np.nan)
        self.freeze_count = np.zeros(self.n_ch, dtype=int)
        self.lockout_ctr = np.zeros(self.n_ch, dtype=int)

    def reset(self):
        """Clear all state. Call before processing a new stream."""
        self._init()

    def check(self, z_k: np.ndarray):
        """
        Classify each channel in the current frame.

        Args:
            z_k: Raw measurements (n_channels,). NaN = missing.

        Returns:
            omega: Quality mask (n_channels,). 1.0=trusted, 0.0=flagged.
            info:  Diagnostic dict with keys: n_roc, n_freeze, n_pred,
                   roc_channels, freeze_channels, pred_channels,
                   is_system_event, n_flagged.
        """
        om = np.ones(self.n_ch)
        roc, frz, prd = [], [], []

        for c in range(self.n_ch):
            if np.isnan(z_k[c]):
                om[c] = 0
                self.z_prev[c] = np.nan
                self.freeze_count[c] = 0
                continue
            if self.lockout_ctr[c] > 0:
                om[c] = 0
                self.lockout_ctr[c] -= 1
                self.z_prev[c] = z_k[c]
                continue
            if np.isnan(self.z_prev[c]):
                self.z_prev[c] = z_k[c]
                continue
            if abs(z_k[c] - self.z_prev[c]) > self.thresholds[c]:
                roc.append(c)
            if z_k[c] == self.z_prev[c]:
                self.freeze_count[c] += 1
                if self.freeze_count[c] >= self.freeze_consec:
                    frz.append(c)
            else:
                self.freeze_count[c] = 0
            if (c not in roc
                    and c not in frz
                    and not np.isnan(self.z_rec_prev[c])
                    and abs(z_k[c] - self.z_rec_prev[c]) > self.thresholds[c]):
                prd.append(c)
            self.z_prev[c] = z_k[c]

        is_sys = len(roc) >= self.n_event
        if is_sys:
            for c in frz:
                om[c] = 0
                self.lockout_ctr[c] = self.lockout
        else:
            for c in roc + frz + prd:
                om[c] = 0
                self.lockout_ctr[c] = self.lockout

        info = {
            "n_roc": len(roc), "n_freeze": len(frz), "n_pred": len(prd),
            "is_system_event": is_sys,
            "roc_channels": roc, "freeze_channels": frz, "pred_channels": prd,
            "n_flagged": int(np.sum(om < 0.5)),
        }
        return om, info

    def update_recovered(self, z_rec: np.ndarray):
        """Feed back recovered signal for next frame's prediction check."""
        self.z_rec_prev = z_rec.copy()


# ====================================================================
#  SAP group (sliding buffer + C++ backend call)
# ====================================================================

class _SAPGroup:
    """
    Sliding window buffer for one channel group.
    Calls sap_core.sap() (C++) when recovery is needed.
    """

    def __init__(self, n_ch: int, L: int, n1: int,
                 rank: int, thresh: float, fast: bool):
        self.n_ch, self.L, self.n1 = n_ch, L, n1
        self.rank, self.thresh, self.fast = rank, thresh, fast
        self._init()

    def _init(self):
        self.buf_data = np.zeros((self.L, self.n_ch))
        self.buf_omega = np.ones((self.L, self.n_ch))
        self.count = 0
        self.last_rec = None

    def reset(self):
        self._init()

    def push(self, z_grp: np.ndarray, om_grp: np.ndarray) -> np.ndarray:
        """
        Push one frame, return recovered values for this group.

        Args:
            z_grp:  Observed values (n_ch,). Masked entries = 0.
            om_grp: Mask (n_ch,). 1.0=observed, 0.0=missing.

        Returns:
            Recovered signal for latest frame (n_ch,).
        """
        self.buf_data[:-1] = self.buf_data[1:]
        self.buf_omega[:-1] = self.buf_omega[1:]
        self.buf_data[-1] = z_grp
        self.buf_omega[-1] = om_grp
        self.count += 1

        if self.count < self.L:
            return z_grp.copy()
        if np.all(self.buf_omega == 1):
            self.last_rec = self.buf_data.copy()
            return self.buf_data[-1].copy()

        x_p = self.buf_data.T.copy()
        if self.last_rec is not None:
            xi = np.zeros_like(self.buf_data)
            xi[:-1] = self.last_rec[1:]
            xi[-1] = self.last_rec[-1]
            x_init = xi.T.copy()
        else:
            x_init = np.empty((0, 0))

        xr, _ = sap_core.sap(x_p, self.n1, self.rank,
                              self.thresh, x_init, self.fast)
        xr = xr.T
        self.last_rec = xr.copy()
        self.buf_data[:] = xr
        return xr[-1].copy()


# ====================================================================
#  SAP recovery manager (multiple groups)
# ====================================================================

class SAPRecovery:
    """
    Manages one _SAPGroup per ChannelGroup.
    Ungrouped channels pass through without recovery.
    """

    def __init__(self, n_channels: int,
                 groups: List[ChannelGroup] = None,
                 sap_config: SAPConfig = None):
        self.n_ch = n_channels
        cfg = sap_config or SAPConfig()

        if not groups:
            groups = [ChannelGroup(list(range(n_channels)), rank=2)]

        seen = set()
        for g in groups:
            for c in g.channels:
                if c < 0 or c >= n_channels:
                    raise ValueError(
                        f"Channel {c} out of range [0, {n_channels})")
                if c in seen:
                    raise ValueError(f"Channel {c} assigned to multiple groups")
                seen.add(c)

        self.groups = groups
        self.ungrouped = [c for c in range(n_channels) if c not in seen]
        self._saps = [
            _SAPGroup(len(g.channels), cfg.window_length,
                      cfg.hankel_rows, g.rank, cfg.threshold, cfg.fast)
            for g in groups
        ]

    def reset(self):
        for s in self._saps:
            s.reset()

    def recover(self, z_k: np.ndarray, omega_k: np.ndarray) -> np.ndarray:
        """
        Recover one frame.

        Args:
            z_k:     Raw measurements (n_channels,). NaN = missing.
            omega_k: Quality mask (n_channels,). 1=ok, 0=bad.

        Returns:
            Recovered signal (n_channels,).
        """
        zc = z_k.copy()
        zc[np.isnan(zc)] = 0.0
        obs = omega_k > 0.5
        zc[~obs] = 0.0

        z_out = zc.copy()
        for g, sg in zip(self.groups, self._saps):
            z_out[g.channels] = sg.push(zc[g.channels],
                                        obs[g.channels].astype(float))
        for c in self.ungrouped:
            z_out[c] = zc[c]
        return z_out


# ====================================================================
#  Top-level interface
# ====================================================================

class TimeSeriesRecovery:
    """
    Complete online recovery pipeline.

    Args:
        n_channels:     Number of input channels.
        groups:         Channel grouping (default: one group, rank=2).
        anomaly_config: AnomalyConfig instance.
        sap_config:     SAPConfig instance.

    Methods:
        reset()                          Clear all state.
        step(z_k)                        Process one frame (auto mask).
        step_with_external_mask(z_k, w)  Process one frame (user mask).
        get_history()                    Return full processing history.
    """

    def __init__(self, n_channels: int,
                 groups: List[ChannelGroup] = None,
                 anomaly_config: AnomalyConfig = None,
                 sap_config: SAPConfig = None):
        self.n_ch = n_channels
        self.anomaly = OnlineAnomalyDetector(n_channels, anomaly_config)
        self.recovery = SAPRecovery(n_channels, groups, sap_config)
        self._hist = {
            "z_raw": [], "omega": [], "z_recovered": [], "anomaly_info": []}

    def reset(self):
        """Clear all internal state. Call before each new data stream."""
        self.anomaly.reset()
        self.recovery.reset()
        self._hist = {
            "z_raw": [], "omega": [], "z_recovered": [], "anomaly_info": []}

    def step(self, z_k: np.ndarray) -> Dict[str, Any]:
        """
        Process one frame with automatic anomaly detection.

        Args:
            z_k: Raw measurements (n_channels,). NaN = missing.

        Returns:
            dict with keys:
                z_recovered  (n_channels,)  Recovered signal.
                omega        (n_channels,)  Mask. 1=ok, 0=flagged.
                anomaly_info dict           Diagnostics.
        """
        z = np.asarray(z_k, dtype=np.float64)
        if z.shape != (self.n_ch,):
            raise ValueError(f"Expected ({self.n_ch},), got {z.shape}")

        omega, info = self.anomaly.check(z)
        z_rec = self.recovery.recover(z, omega)
        self.anomaly.update_recovered(z_rec)

        self._hist["z_raw"].append(z.copy())
        self._hist["omega"].append(omega.copy())
        self._hist["z_recovered"].append(z_rec.copy())
        self._hist["anomaly_info"].append(info)

        return {"z_recovered": z_rec, "omega": omega, "anomaly_info": info}

    def step_with_external_mask(self, z_k: np.ndarray,
                                omega_ext: np.ndarray) -> Dict[str, Any]:
        """
        Process one frame with a user-supplied quality mask.
        Skips internal anomaly detection.

        Args:
            z_k:       Raw measurements (n_channels,).
            omega_ext: External mask (n_channels,). 1=trusted, 0=missing.

        Returns:
            Same dict structure as step().
        """
        z = np.asarray(z_k, dtype=np.float64)
        omega = np.asarray(omega_ext, dtype=np.float64)

        z_rec = self.recovery.recover(z, omega)
        self.anomaly.update_recovered(z_rec)

        self._hist["z_raw"].append(z.copy())
        self._hist["omega"].append(omega.copy())
        self._hist["z_recovered"].append(z_rec.copy())
        self._hist["anomaly_info"].append({"external_mask": True})

        return {"z_recovered": z_rec, "omega": omega,
                "anomaly_info": {"external_mask": True}}

    def get_history(self) -> Dict[str, np.ndarray]:
        """
        Return full processing history.

        Returns:
            dict with keys:
                Z_raw        (n_channels, n_frames)
                Z_recovered  (n_channels, n_frames)
                Omega        (n_channels, n_frames)
                anomaly_info list[dict]
        """
        return {
            "Z_raw": np.array(self._hist["z_raw"]).T,
            "Z_recovered": np.array(self._hist["z_recovered"]).T,
            "Omega": np.array(self._hist["omega"]).T,
            "anomaly_info": self._hist["anomaly_info"],
        }