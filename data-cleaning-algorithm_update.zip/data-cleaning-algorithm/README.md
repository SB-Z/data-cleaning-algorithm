# TimeSeriesRecovery — User Guide

Multi-channel time-series missing-data recovery tool.
It automatically detects sensor faults (missing values, frozen sensors, spikes)
and reconstructs the corrupted data using cross-channel temporal correlation,
frame by frame, in an **online (streaming)** fashion.

> **If you are adapting this to data at a different sampling rate than the
> examples were tuned for, read [Adapting to Your Sampling Rate](#adapting-to-your-sampling-rate) first.**
> Most "it works on the demo data but not on mine" problems come from two
> things: the data is not normalized, and a few parameters are counted in
> *number of samples* (so the defaults, sized for one sampling rate, do not
> fit another).

---

## Requirements

- Python **3.12** (must match the included `.pyd` / `.so` module version).
- `numpy`: `pip install numpy`

### Using a different Python version or OS

The compiled backend `sap_core` is built for a **specific Python version,
CPU architecture, and OS**. A `sap_core.cp312-win_amd64.pyd` only imports on
CPython 3.12, 64-bit, Windows. If you are on another version/OS you must
rebuild it from source:

```bash
# needs a C++ compiler (MSVC on Windows, gcc/clang on Linux/Mac)
pip install pybind11 numpy setuptools
# from the folder that contains sap_core.cpp, setup.py and eigen-3.4.0/
python setup.py build_ext --inplace
```

The build is cross-platform (`setup.py` switches compiler flags by OS), but the
output binary is platform-specific: each machine must build its own.

---

## Files

| File | Description |
|------|-------------|
| `time_series_recovery.py` | Python interface. Import this in your code. |
| `sap_core.*.pyd` / `sap_core.*.so` | Pre-compiled C++ backend. Must be on your Python path (e.g. same directory). |

---

## Quick Start

```python
import numpy as np
from time_series_recovery import TimeSeriesRecovery

# data shape: (n_channels, n_frames) — e.g. 6 sensors, 500 time steps
data = np.load("my_data.npy")          # shape (6, 500)

rec = TimeSeriesRecovery(n_channels=6)
rec.reset()
for k in range(data.shape[1]):
    result = rec.step(data[:, k])      # feed one frame at a time

hist = rec.get_history()
recovered = hist["Z_recovered"]        # shape (6, 500)
```

NaN values and frozen sensors are detected and recovered automatically.

> ⚠️ **Before relying on this, see [Preparing Your Data](#preparing-your-data-normalization).**
> The quick start works on data that is already at a sensible scale (roughly
> unit amplitude). Raw physical units (e.g. voltages of ±6000) will make the
> recovery diverge — normalize first.

---

## Input Data Format

A 2-D numpy array, shape `(n_channels, n_frames)`:

```
         frame0  frame1  frame2  frame3 ...
channel0 [ 0.5    0.6    0.7    NaN   ...]   <- NaN = missing
channel1 [ 0.3    0.3    0.3    0.3   ...]   <- repeated value = frozen sensor
channel2 [ 1.2    1.3    1.1    1.2   ...]   <- normal
channel3 [ 0.8    0.9    5.0    0.7   ...]   <- 5.0 = spike
```

Handled automatically:

- **NaN** → missing data, recovered from other channels.
- **Repeated identical values** → frozen sensor, recovered.
- **Sudden spikes** → anomaly, recovered.
- **All channels spike at once** → treated as a real system event, **not** corrected.

There is an important difference between these:

- **NaN/missing** does **not** go through anomaly detection — it is recovered
  directly. It works almost regardless of parameter tuning.
- **Spikes and freezes** must be **detected first** by the anomaly detector.
  If the detector is mis-tuned, these fail even though NaN still works. If you
  see "NaN recovers but spikes/freezes don't", the detector settings (threshold,
  lockout) are the problem — see [AnomalyConfig](#anomalyconfig).

---

## Preparing Your Data: Normalization

**This is the single most important preprocessing step.** The recovery math and
the detection thresholds are **scale-dependent**. If your data is in raw
physical units (large magnitude, non-zero mean), the low-rank reconstruction can
diverge to huge values. Bring each signal group to roughly unit scale before
recovery, and convert the output back afterward.

```python
# Choose a healthy warm-up window (no faults). See "Adapting to Your Sampling
# Rate" for how long it must be (at least one full signal cycle).
warm = clean_warmup            # shape (n_channels, N_warm)

mu = warm.mean(axis=1, keepdims=True)          # per-channel mean (offset)
scale = np.empty((n_channels, 1))
# scale each *signal group* by its own RMS/std (keeps relative amplitudes):
scale[V_idx] = warm[V_idx].std()               # e.g. voltage channels
scale[I_idx] = warm[I_idx].std()               # e.g. current channels
scale[scale == 0] = 1.0

def normalize(x):   return (x - mu) / scale     # feed this into rec.step()
def denormalize(z): return z * scale + mu       # apply to the recovered output
```

Notes:

- **Scale by group, not globally**, when you mix signal types (volts vs amps):
  divide all voltages by the voltage scale, all currents by the current scale.
- **Centering** (subtracting the mean) is optional but recommended — a constant
  offset otherwise consumes one rank dimension. For balanced 3-phase signals the
  three per-phase offsets cancel, so centering preserves the balance.
- Estimate `mu` and `scale` from a **healthy** window only, never from data that
  already contains faults (a spike would inflate the scale).

---

## Classes You Need to Import

```python
from time_series_recovery import (
    TimeSeriesRecovery,   # main class — always needed
    ChannelGroup,         # define channel groups        (optional)
    AnomalyConfig,        # anomaly-detection settings    (optional)
    SAPConfig,            # recovery-algorithm settings   (optional)
)
```

---

## TimeSeriesRecovery — Main Class

### Constructor

```python
rec = TimeSeriesRecovery(
    n_channels,            # required: total channels per frame
    groups=None,           # optional: list of ChannelGroup
    anomaly_config=None,   # optional: AnomalyConfig
    sap_config=None,       # optional: SAPConfig
)
```

| Argument | Type | Required | Description |
|----------|------|:--------:|-------------|
| `n_channels` | int | Yes | Total number of channels. Must match the length of each frame you feed in. |
| `groups` | list of ChannelGroup | No | How to group channels for recovery. Default: all channels in one group, rank=2. |
| `anomaly_config` | AnomalyConfig | No | Anomaly-detection parameters. Defaults work for most cases. |
| `sap_config` | SAPConfig | No | Recovery-algorithm parameters. Defaults work for most cases. |

### Methods

#### `rec.reset()`

Clear all internal state. **Must call before processing each new data stream.**

#### `rec.step(frame)`

Process one time frame. Automatically detects anomalies and recovers data.
**Input:** one column of your data `(n_channels,)`; use `NaN` for missing values.
**Output:** a dict with three keys:

| Key | Type | Description |
|-----|------|-------------|
| `"z_recovered"` | np.ndarray (n_channels,) | Recovered signal. Missing/corrupted values filled in; normal values pass through unchanged. |
| `"omega"` | np.ndarray (n_channels,) | Quality mask for this frame. `1.0` = trusted, `0.0` = flagged and recovered. |
| `"anomaly_info"` | dict | Diagnostic details. See [Anomaly Info Dict](#anomaly-info-dict). |

#### `rec.step_with_external_mask(frame, omega)`

Same as `step()`, but you supply your own quality mask instead of the built-in
detector. Use this when you already know which channels are bad.

```python
omega = np.ones(n_channels)
omega[3] = 0.0          # mark channel 3 as bad
result = rec.step_with_external_mask(frame, omega)
```

#### `rec.get_history()`

After processing all frames, retrieve the complete input/output history:

| Key | Type | Description |
|-----|------|-------------|
| `"Z_raw"` | np.ndarray (n_channels, n_frames) | All raw input frames as received. |
| `"Z_recovered"` | np.ndarray (n_channels, n_frames) | All recovered output frames. |
| `"Omega"` | np.ndarray (n_channels, n_frames) | Quality-mask history. 1=trusted, 0=flagged. |
| `"anomaly_info"` | list of dict | Per-frame diagnostic info. |

---

## Channel Groups

By default all channels form one group (`rank=2`). Splitting different signal
types into separate groups is physically cleaner but, **after normalization,
usually makes little difference to accuracy** — the bigger levers are `rank` and
`window_length`. Group when it makes the model clearer, not as a fix.

```python
ChannelGroup(channels, rank=2, label="")
```

```python
# voltages in one group, currents in another
groups = [
    ChannelGroup([0, 1, 2], rank=4, label="V"),
    ChannelGroup([3, 4, 5], rank=4, label="I"),
]
```

### Rules

- Each channel can only be in **one** group.
- Channels **not** in any group pass through without recovery.
- Minimum **2 channels** per group (1-channel groups cannot recover anything).
- Channels in the same group should be **correlated** with each other.
- See also [Recovery Limit](#recovery-limit--fewer-than-half-the-channels-may-fail-at-once):
  at any instant fewer than half a group's channels may be bad.

### Examples

**Default (no groups) — all channels in one group, rank=2:**

```python
rec = TimeSeriesRecovery(n_channels=6)
# Equivalent to: groups=[ChannelGroup([0,1,2,3,4,5], rank=2)]
```

**Two groups with different rank:**

```python
rec = TimeSeriesRecovery(
    n_channels=8,
    groups=[
        ChannelGroup([0, 1, 2, 3], rank=2),    # simple signals
        ChannelGroup([4, 5, 6, 7], rank=4),    # complex signals
    ],
)
```

**Three groups, some channels ungrouped (they pass through unrecovered):**

```python
rec = TimeSeriesRecovery(
    n_channels=12,
    groups=[
        ChannelGroup([0, 1, 2], rank=2, label="A"),
        ChannelGroup([3, 4, 5], rank=2, label="B"),
        ChannelGroup([6, 7, 8], rank=3, label="C"),
        # channels 9, 10, 11 are NOT in any group -> passed through as-is
    ],
)
```

### How to choose `rank`

`rank` = number of independent signal components in a group. **It depends on the
signal structure, not on the sampling rate.**

| Your signals look like | rank |
|------------------------|------|
| All channels are the same waveform with offsets/scaling | 2 |
| Single-frequency sinusoid (e.g. 60 Hz power) | 2 |
| Balanced 3-phase (the three phases sum to zero) | 2 per 3-phase group |
| Sinusoid + one harmonic (60 Hz + 120 Hz) | 3–4 |
| Voltages **and** currents together, or for robust long-gap fill | 4 |
| Multiple frequencies mixed | 4–6 |
| You don't know | start at 2, increase |

- **Too low:** recovered signal looks smoothed, misses real features (and long
  gaps are filled poorly).
- **Too high:** recovered signal is noisier, may be worse than the input.

Programmatic estimate from clean reference data:

```python
from numpy.linalg import svd
U, s, Vt = svd(clean_data, full_matrices=False)
energy = np.cumsum(s**2) / np.sum(s**2)
rank = int(np.searchsorted(energy, 0.95) + 1)
```

---

## Recovery Limit — Fewer Than Half the Channels May Fail at Once

This is a **hard mathematical limit**, not a tuning issue: at any single time
instant, **fewer than half** of the channels *in a group* may be corrupted. If
half or more go bad simultaneously, recovery cannot succeed — no parameter
setting can fix it.

```
            n_corrupt  <  n_total / 2          (per group, at every instant)
   equivalently:  at least half the channels must stay valid
                  (and never fewer than `rank` valid channels)
```

**Why (the math):** recovery reconstructs the bad channels *from* the good ones
using a low-rank model. The good channels are the equations; the bad channels
are the unknowns. To solve for the unknowns you need enough independent
equations — at least `rank` valid channels, and for stable results more good
than bad. Once half or more of a group is missing at the same time, the system
is **underdetermined**: there are more unknowns than the data can pin down, so
the answer is not unique and the reconstruction drifts or collapses.

**It applies per group, and per instant:**

| Channels in the group | Max corrupted at one instant |
|-----------------------|------------------------------|
| 3 (e.g. 3-phase)      | 1 |
| 4                     | 1 |
| 6                     | 2 |
| `n`                   | `< n / 2` |

Note it is *per time frame*, not over the whole record. A channel can be bad for
a long stretch and still be recovered — as long as, at each instant, the other
channels in its group still satisfy the rule. (Example: in a balanced 3-phase
group, one frozen phase recovers fine from the other two; but freeze or drop
*two* of the three at the same time and that group becomes unrecoverable.)

**Practical implications:**

- **Keep redundancy in every group.** A 3-phase group has no margin for two
  simultaneous failures — design for at most one bad phase at a time.
- **Don't put weakly-correlated channels in the same group** just to pad the
  count; only channels that actually constrain each other count as useful
  "equations".
- **Spread correlated risks across groups** so a single common-mode event does
  not take out half of one group at once.

---

## AnomalyConfig

```python
AnomalyConfig(
    thresholds=0.5,
    freeze_consec=2,
    lockout_samples=16,
    n_event_threshold=3,
)
```

### `thresholds`  — *sample-rate dependent*

**What:** the maximum sample-to-sample change allowed in normal operation. A
larger jump flags the channel as anomalous. `float` (all channels) or `list`
(per channel).

**How to set — estimate it from a healthy window, do not hardcode a number:**

```python
# warm must be HEALTHY and span >= one full signal cycle (see sampling section)
diff = np.abs(np.diff(normalize(warm), axis=1))
thresholds = np.percentile(diff, 99, axis=1) * 3.0    # per channel
```

- **Estimate it on normalized data**, the same data you feed into `step()`.
- **The warm-up window must cover at least one full cycle of the signal.** A
  window shorter than one cycle sees only a flat sliver and produces a threshold
  that is too low on some channels.
- **Re-estimate whenever the sampling rate or scale changes.** A threshold value
  is not portable between rates.

**If too small:** normal fluctuations get falsely flagged → the algorithm
"recovers" data that was fine → errors. (This is the most common failure.)
**If too large:** real faults are missed → corrupted data passes through.

### `freeze_consec`  — *not rate dependent*

How many **identical** consecutive values trigger a frozen-sensor flag.
- Float/analog data: `2` (real analog signals almost never repeat exactly).
- Integer / heavily quantized data: `5–10`.

### `lockout_samples`  — *sample-rate dependent*

**What:** after a channel is flagged, keep it masked for this many extra frames.
A debounce that stops the channel flickering between "good" and "bad".

**How to set:** this is a **count of samples**, so a higher sampling rate needs a
**smaller** value. Set it to a *small fraction of one cycle* — just enough to
ride out detection chatter.

> ⚠️ The old rule "0.5–1× `window_length`" **over-masks on fast signals.** At
> 20 kHz, `lockout_samples=12` once turned 3 real spikes into ~180 masked frames
> (a cascade: the long mask lets the recovery drift, the next real sample then
> looks "wrong", and the mask snowballs). Keep it small.

| Sampling rate | suggested `lockout_samples` |
|---------------|-----------------------------|
| ~hundreds of Hz (slow) | 8–16 |
| ~tens of kHz (fast) | 1–3 |

### `n_event_threshold`  — *not rate dependent*

If this many channels spike **at the same time**, the frame is treated as a real
system event (not a sensor fault) and those channels are **not** flagged.
Set it to the number of channels in a group (or the number you'd expect to move
together during a genuine event).

---

## SAPConfig

```python
SAPConfig(
    window_length=16,
    hankel_rows=2,
    threshold=0.01,
    fast=True,
)
```

### `window_length`  — *sample-rate dependent*

**What:** how many recent frames are kept to rebuild a bad channel.

**The rule:** it must be **larger than the longest gap/freeze you expect**,
measured in samples:

```
window_length  >  longest_expected_gap_seconds * sampling_rate
```

If a channel is missing for the whole window, there is no good data left for it
in that window and the low-rank fit cannot reconstruct it. A higher sampling
rate makes the same real-time gap span more samples, so you need a larger
window. Keep it a **modest fraction of one cycle** so the in-window signal stays
simple (close to a single arc), which the low-rank model handles best.

| Situation | suggested `window_length` |
|-----------|---------------------------|
| Short gaps, fast sampling | 16–24 |
| Longer gaps / freezes | 32–48 (≥ longest gap) |
| Minimum latency | 8–10 |

**Constraint:** must be `> rank + hankel_rows`.
**Too small:** not enough history → recovery may oscillate or diverge.
**Too large:** more compute; also the first `window_length` frames output raw
(unrecovered) values while the buffer fills.

### `hankel_rows`  — *not rate dependent*

Internal Hankel construction parameter. Leave at `2`. Only raise to `3–4` if
`window_length` is large (>30) and you want longer-range temporal structure.

### `threshold`  — *scale dependent, not rate dependent*

Sparsity threshold for the SAP inner loop. **This is why normalization matters:**
`0.01` is right for unit-scale data; on raw large-magnitude data it is
effectively zero and recovery misbehaves. Normalize, then leave it near default.

| Data quality | value |
|--------------|-------|
| Very clean | 0.005 |
| Typical | 0.01 |
| Noisy | 0.05–0.1 |

### `fast`  — *not rate dependent*

`True` (default) = 5 iterations/rank, ~2× faster, slightly less accurate.
`False` = 10 iterations/rank, slower, more accurate. Use `True` for real-time.

---

## Adapting to Your Sampling Rate

**The core idea:** several parameters are counted in *number of samples*, not in
time. The same number means a different amount of signal at a different sampling
rate, so settings tuned at one rate do not transfer to another. To port them:
**express each setting in time (or as a fraction of one signal cycle), then
multiply by your sampling rate.**

Worked illustration — the threshold warm-up window of "30 samples":

| | 800 Hz (slow) | 20 kHz (fast) |
|--|---------------|----------------|
| 30 samples = | 37.5 ms ≈ 2 cycles → representative ✔ | 1.5 ms ≈ 0.09 cycle → far too short ✘ |

The same 30-sample window that is fine at 800 Hz is useless at 20 kHz.

### Cheat sheet

`fs` = sampling rate (Hz), `f` = signal fundamental (Hz, e.g. 60).

| Setting | General rule (any `fs`) | e.g. 800 Hz / 60 Hz | e.g. 20 kHz / 60 Hz |
|---------|-------------------------|---------------------|---------------------|
| **Normalize per group** | Always; de-normalize output | required | required |
| **Threshold warm-up length** | ≥ 1 cycle: `N ≥ fs / f` | ~14 → use ≥ 1 cycle | ~333 → use ~400 |
| **Threshold value** | `p99(|Δ| on warm-up) × 2–3`, per channel; re-estimate | re-estimate | re-estimate |
| **`lockout_samples`** | small fraction of a cycle | 8–16 | 2 |
| **`window_length`** | `>` longest expected gap (= gap_sec × fs); modest fraction of a cycle | 16 | 24 (↑ for long gaps) |
| **`rank`** | signal components per group (rate-independent) | per signal | per signal |
| **`hankel_rows`, `freeze_consec`, `threshold`, `fast`** | rate-independent | defaults | defaults |

### Recipe

1. Pick a **healthy warm-up window** of at least one full cycle (`N ≥ fs / f`).
2. From it, compute the **normalization** (`mu`, `scale`) and the **per-channel
   threshold** (`p99(|Δ|) × ~3` on the normalized warm-up).
3. Set `lockout_samples` small for fast data (e.g. 2 at 20 kHz).
4. Set `window_length` larger than your longest expected gap/freeze.
5. Set `rank` from the signal structure (4 is a good default for 3-phase V+I).
6. Stream the data through `step()` on **normalized** frames, then
   **de-normalize** the recovered output.

---

## Anomaly Info Dict

Each call to `step()` returns an `anomaly_info` dictionary with these fields:

| Key | Type | Description |
|-----|------|-------------|
| `"n_roc"` | int | Number of channels that exceeded the rate-of-change threshold this frame. |
| `"n_freeze"` | int | Number of channels detected as frozen this frame. |
| `"n_pred"` | int | Number of channels that deviated from the predicted (last recovered) value. |
| `"is_system_event"` | bool | `True` if the frame was classified as a real system event (not a sensor fault). |
| `"roc_channels"` | list of int | Which channels had rate-of-change spikes. |
| `"freeze_channels"` | list of int | Which channels were frozen. |
| `"pred_channels"` | list of int | Which channels failed the prediction check. |
| `"n_flagged"` | int | Total number of channels with omega=0 this frame. |

---

## Complete Example (online, with normalization + warm-up calibration)

```python
import numpy as np
from time_series_recovery import (
    TimeSeriesRecovery, ChannelGroup, AnomalyConfig, SAPConfig
)

data = np.load("sensor_data.npy")      # (n_channels, n_frames), raw units
n_ch = data.shape[0]

# --- 1. sampling info ---
fs, f_signal = 20_000, 60.0
N_warm = int(np.ceil(fs / f_signal)) + 40        # >= one cycle of HEALTHY data
warm = data[:, :N_warm]                          # must be fault-free

# --- 2. normalization from the warm-up window ---
V_idx, I_idx = [0, 1, 2], [3, 4, 5]
mu = warm.mean(axis=1, keepdims=True)
scale = np.ones((n_ch, 1))
scale[V_idx] = warm[V_idx].std()
scale[I_idx] = warm[I_idx].std()
scale[scale == 0] = 1.0
normalize   = lambda x: (x - mu) / scale
denormalize = lambda z: z * scale + mu

# --- 3. per-channel anomaly threshold from the warm-up window ---
diff = np.abs(np.diff(normalize(warm), axis=1))
thresholds = np.percentile(diff, 99, axis=1) * 3.0

# --- 4. build the recovery instance ---
rec = TimeSeriesRecovery(
    n_channels=n_ch,
    groups=[ChannelGroup(V_idx, rank=4), ChannelGroup(I_idx, rank=4)],
    anomaly_config=AnomalyConfig(
        thresholds=thresholds,
        freeze_consec=2,
        lockout_samples=2,             # small: fast sampling
        n_event_threshold=3,           # = channels per group
    ),
    sap_config=SAPConfig(
        window_length=24,              # > longest expected gap
        hankel_rows=2,
        threshold=0.01,
        fast=True,
    ),
)

# --- 5. stream (normalized in, de-normalized out) ---
rec.reset()
for k in range(data.shape[1]):
    rec.step(normalize(data[:, k]))

hist = rec.get_history()
recovered = denormalize(hist["Z_recovered"])      # back to physical units
mask = hist["Omega"]                               # 1=trusted, 0=flagged
```

---

## Troubleshooting / FAQ

**Recovery diverges / outputs huge values (e.g. ~1e6).**
Your data is not normalized. Scale it to ~unit amplitude before `step()` and
de-normalize the output. See [Preparing Your Data](#preparing-your-data-normalization).

**NaN/missing recovers fine, but spikes and freezes don't.**
NaN skips detection; spikes/freezes must be detected first. It's the detector
settings — usually `thresholds` (estimated from too short a window) and/or
`lockout_samples` (too large for your sampling rate). See [AnomalyConfig](#anomalyconfig).

**Some healthy channels get heavily flagged.**
The threshold is too low for those channels — usually because it was estimated
from a warm-up window shorter than one cycle. Use a longer healthy window
(`N ≥ fs / f`) and re-estimate.

**It worked on the demo data but not on mine.**
Almost always: (1) not normalized, and (2) parameters not adjusted for your
sampling rate. See [Adapting to Your Sampling Rate](#adapting-to-your-sampling-rate).

**Recovery fails when several channels go bad together.**
There is a hard limit: at any instant, fewer than half the channels in a group
may be corrupted (you need at least `rank` valid channels, and more good than
bad). If half or more fail simultaneously the problem is underdetermined and no
algorithm can recover it. See
[Recovery Limit](#recovery-limit--fewer-than-half-the-channels-may-fail-at-once).

**Recovery degrades during a long outage.**
Expected if the gap/freeze is longer than `window_length`. Increase
`window_length` beyond your longest expected gap, or for a permanent failure
drop that channel.

**`ModuleNotFoundError: sap_core` or `ImportError: DLL load failed`.**
The compiled backend isn't found or doesn't match your Python. Ensure
`sap_core.*` is on your path and your Python version/OS/architecture matches the
binary, or rebuild from source (see [Requirements](#requirements)).

**The first few frames look raw/unprocessed.**
Normal. The algorithm needs `window_length` frames to fill its buffer before
recovery starts.

**Can I process in batch?**
No — it's online. Feed one frame at a time via `step()` (loop over columns).

**I have only 1 channel.**
Recovery will be poor; it relies on correlation between channels. Use ≥ 2
correlated channels.

**How do I know my parameters are good?**
If you have reference (known-good) data, compute RMSE between recovered and true,
ideally normalized by each channel's scale (NRMSE). Tune `rank` and
`window_length` first, then the detector settings.
